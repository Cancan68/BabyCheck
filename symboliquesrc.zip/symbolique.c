#include <PalmOS.h>				
#include "symbolique.h"
#include "lang.h"

#ifdef CONFIG_SONY
  #include <SonyCLIE.h>

  UInt16  sonyLibRefNum;
#endif /* CONFIG_SONY */

static Err StartApplication(void)
{

#ifdef CONFIG_SONY

/* find out whether we are running on a sony high-resolution screen --------- */
  sonyLibRefNum = 0; 

  {
    SonySysFtrSysInfoP sonySysFtrSysInfoP;
    Err error = 0;

    if(!FtrGet(sonySysFtrCreator, sonySysFtrNumSysInfoP, (UInt32 *)&sonySysFtrSysInfoP))
    {
      if(sonySysFtrSysInfoP->libr & sonySysFtrSysInfoLibrHR)
      {
        if( (error = SysLibFind(sonySysLibNameHR, &sonyLibRefNum)))
        {
          if(error == sysErrLibNotFound)
          {
            error = SysLibLoad( 'libr', sonySysFileCHRLib, &sonyLibRefNum);
          }
        }
      }
    }
  }

  if(sonyLibRefNum)
  {
    UInt32  width, height, depth;

    HROpen(sonyLibRefNum);
    width = hrWidth;
    height = hrHeight;
    depth = 8;      // (256 colors)
    HRWinScreenMode(sonyLibRefNum, winScreenModeSet, &width, &height, &depth, NULL);
  }

#endif /* CONFIG_SONY */

  FrmGotoForm(formID_main);
  return 0;
}

static void StopApplication(void)
{
  FrmCloseAllForms();

#ifdef CONFIG_SONY
  if(sonyLibRefNum)
  {
    HRWinScreenMode(sonyLibRefNum, winScreenModeSetToDefaults, NULL, NULL, NULL, NULL);
    HRClose(sonyLibRefNum);
  }
#endif /* CONFIG_SONY */
}

static void SetFieldTextFromStr(UInt16 fieldID, Char *strP)
{
  MemHandle txtH, oldTxtH;
  FormPtr frm = FrmGetActiveForm();
  FieldPtr fldP;
	
  txtH = MemHandleNew(StrLen(strP) + 1);
  if (txtH)
  {
    StrCopy(MemHandleLock(txtH), strP);
    MemHandleUnlock(txtH);
    fldP = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, fieldID));
    oldTxtH = FldGetTextHandle(fldP);
    FldSetTextHandle(fldP, txtH);
    FldDrawField(fldP);
    if (oldTxtH)
      MemHandleFree(oldTxtH);
  }
}

static void SetFieldTextFromInt(UInt16 fieldID, UInt16 numP)
{
  MemHandle txtH, oldTxtH;
  FormPtr frm = FrmGetActiveForm();
  FieldPtr fldP;

  txtH = MemHandleNew(20);
  if (txtH)
  {
    StrIToA(MemHandleLock(txtH), numP);
    MemHandleUnlock(txtH);
    fldP = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, fieldID));
    oldTxtH = FldGetTextHandle(fldP);
    FldSetTextHandle(fldP, txtH);
    FldDrawField(fldP);
    if (oldTxtH)
      MemHandleFree(oldTxtH);
  }
}

static UInt16 ModuloNumb(UInt16 number)
{
  UInt16 part_beg, part_end;

  if (number > 10 || number == 10)
  {
       part_beg = number / 10;
       part_end = number % 10;
       
       number = part_beg + part_end;
       number = ModuloNumb(number);
  }
  return number;
}

static UInt16 ModuloSign(UInt16 number)
{
  if (number > 360)
  {
       number -= 360;
       number = ModuloSign(number);
  }
  return number;
}

static void Calculate(void)
{
  FormType *frmP;
  FieldType *fieldP;
  Char *f_name;
  Int16 index;
  UInt16 len, numb_i, sign_i;

  frmP = FrmGetActiveForm();
  index = FrmGetObjectIndex(frmP, fieldID_firstname);
  fieldP = FrmGetObjectPtr(frmP, index);
  len = FldGetTextLength(fieldP);
  f_name = FldGetTextPtr(fieldP);

  if (!len || !f_name)
  {
    SetFieldTextFromStr(fieldID_number, " ");
    SetFieldTextFromStr(fieldID_sign, " ");
    SetFieldTextFromStr(fieldID_period, " ");
    return;
  }

  numb_i = 0;
  sign_i = 0;

  while (*f_name)
  {
    switch (*f_name)
    {
      case 'a':
      case 'A':
      case '�':
      case '�':
        numb_i += 1;
        sign_i += 1;
        break;
      case 'b':
      case 'B':
        numb_i += 2;
        sign_i += 2;
        break;
      case 'c':
      case 'C':
      case '�':
        numb_i += 3;
        sign_i += 20;
        break;
      case 'd':
      case 'D':
        numb_i += 4;
        sign_i += 4;
        break;
      case 'e':
      case 'E':
      case '�':
      case '�':
      case '�':
        numb_i += 5;
        sign_i += 5;
        break;
      case 'f':
      case 'F':
        numb_i += 6;
        sign_i += 80;
        break;
      case 'g':
      case 'G':
        numb_i += 7;
        sign_i += 3;
        break;
      case 'h':
      case 'H':
        numb_i += 8;
        sign_i += 8;
          break;
      case 'i':
      case 'I':
      case '�':
        numb_i += 9;
        sign_i += 10;
        break;
      case 'j':
      case 'J':
        numb_i += 1;
        sign_i += 10;
        break;
      case 'k':
      case 'K':
        numb_i += 2;
        sign_i += 20;
        break;
      case 'l':
      case 'L':
        numb_i += 3;
        sign_i += 30;
        break;
      case 'm':
      case 'M':
        numb_i += 4;
        sign_i += 40;
        break;
      case 'n':
      case 'N':
        numb_i += 5;
        sign_i += 50;
        break;
      case 'o':
      case 'O':
      case '�':
      case '�':
        numb_i += 6;
        sign_i += 70;
        break;
      case 'p':
      case 'P':
        numb_i += 7;
        sign_i += 80;
        break;
      case 'q':
      case 'Q':
        numb_i += 8;
        sign_i += 100;
        break;
      case 'r':
      case 'R':
        numb_i += 9;
        sign_i += 200;
        break;
      case 's':
      case 'S':
        numb_i += 1;
        sign_i += 300;
        break;
      case 't':
      case 'T':
        numb_i += 2;
        sign_i += 400;
        break;
      case 'u':
      case 'U':
      case '�':
      case '�':
        numb_i += 3;
        sign_i += 6;
        break;
      case 'v':
      case 'V':
        numb_i += 4;
        sign_i += 6;
        break;
      case 'w':
      case 'W':
        numb_i += 5;
        sign_i += 6;
        break;
      case 'x':
      case 'X':
        numb_i += 6;
        sign_i += 60;
        break;
      case 'y':
      case 'Y':
        numb_i += 7;
        sign_i += 10;
        break;
      case 'z':
      case 'Z':
        numb_i += 8;
        sign_i += 7;
        break;
    }
    f_name++;
  }

  numb_i = ModuloNumb(numb_i);
  sign_i = ModuloSign(sign_i);
  if (sign_i > 30)
      sign_i = ((sign_i - 1) / 30);
  else
      sign_i = 0;
 
  SetFieldTextFromInt(fieldID_number, numb_i);

  SetFieldTextFromStr(fieldID_sign, ZodiacalSign[sign_i]);

  SetFieldTextFromStr(fieldID_period, ZodiacalPeriod[sign_i]);
}

static Boolean MainFormHandleEvent(EventPtr event)
{
  Boolean handled = false;
  FormType *frmP;
  
  switch (event->eType)
  {

  case frmOpenEvent:	
    FrmDrawForm(FrmGetActiveForm());
    break;

  case menuEvent:
    MenuEraseStatus(0);
    if (event->data.menu.itemID == menuitemID_info)
    {
      FrmHelp(stringID_info);
      handled = true;
    };
    if(event->data.menu.itemID == menuitemID_about)
    {
      frmP = FrmInitForm(formID_about);
      FrmDoDialog(frmP);
      FrmDeleteForm(frmP);
      handled = true;
    }
    break;

  case ctlSelectEvent:
    if (event->data.ctlEnter.controlID == buttonID_calculate)
    {
        Calculate();
        handled = true;
    } 
    break;

  }			
  return(handled);
}

static Boolean ApplicationHandleEvent(EventPtr event)
{
  FormPtr frm;
  Int16	formId;
  Boolean handled = false;

  if (event->eType == frmLoadEvent) {
    // Load the form resource specified in the event then activate the form.
    formId = event->data.frmLoad.formID;
    frm = FrmInitForm(formId);
    FrmSetActiveForm(frm);

    // Set the event handler for the form.  The handler of the currently 
    // active form is called by FrmDispatchEvent each time it receives an event
    switch (formId) {
    case formID_main:
      FrmSetEventHandler(frm, MainFormHandleEvent);
      handled = true;
      break;
    }
  }
  return handled;
}

static void EventLoop(void)
{
  EventType event;
  UInt16 error;
	
  do {
    EvtGetEvent(&event, evtWaitForever);
    if (!SysHandleEvent(&event))
      if (!MenuHandleEvent(0, &event, &error))
	if (!ApplicationHandleEvent(&event))
	  FrmDispatchEvent(&event);
  }
  while (event.eType != appStopEvent);
}

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
  Err error = 0;		
  if (cmd == sysAppLaunchCmdNormalLaunch) {
    if ((error = StartApplication()) == 0) {   
      EventLoop();
      StopApplication();
    }
  }
  return error;
}
