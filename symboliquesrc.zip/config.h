/* Sony Clie support*/
/* undefine the CONFIG_SONY to build a version without this support */
#undef CONFIG_SONY
//#define CONFIG_SONY
