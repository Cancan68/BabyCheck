#include "config.h"

#define bitmapID_app		10

#define formID_main		1000
#define formID_about		1001

#define menuID_main		1100
#define menuitemID_info		1100
#define menuitemID_about	1101

#define buttonID_calculate	1200

#define stringID_info		2000

#define fieldID_firstname	3000
#define fieldID_number		3001
#define fieldID_sign		3002
#define fieldID_period		3003

#define labelID_firstname	4000
#define labelID_number		4001
#define labelID_signe		4002
